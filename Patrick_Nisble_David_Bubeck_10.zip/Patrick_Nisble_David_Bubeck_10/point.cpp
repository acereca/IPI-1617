#include <string>
#include <iostream>
#include <cassert>

class Point
{
  private:
    // die Koordinaten des Punktes
    double x_;
    double y_;

  public:

    // Standardkonstruktor: initialisiere Punkt (0,0)
    Point()
    : x_(0.0)
    , y_(0.0)
    {}

    // Konstruktor mit zwei Koordinaten: initialisiere Punkt (x,y)
    Point(double x, double y)
    : x_(x)
    , y_(y)
    {}

    // Getter-Funktionen fuer die Koordinaten
    double x() const
    {
        return (*this).x_;
    }

    double y() const
    {
        return (*this).y_;
    }

    // teste ob zwei Punkte gleich sind
    bool operator==(Point const & other) const
    {
        return (*this).x() == other.x() && (*this).y() == other.y();
    }

    // teste ob zwei Punkte ungleich sind
    bool operator!=(Point const & other) const
    {
        return (*this).x() != other.x() || (*this).y() != other.y();
    }

    // erzeuge neuen Punkt, desssen x- und y-Koordinate
    // vertauscht sind
    Point transpose() const
    {
        Point res((*this).y(), (*this).x());
        return res;
    }

    // erzeuge neuen Punkt, der um den Vektor v verschoben ist
    Point translate(Point const & v) const
    {
        Point res((*this).x() + v.x(), (*this).y() + v.y());
        return res;
    }
};

// wandle den Punkt in einen String der Form "[x, y]"
std::string to_string(Point const & p)
{
    return "[" + std::to_string(p.x()) + ", " + std::to_string(p.y()) + "]";
}

// Implementieren Sie hier die arithmetischen Operationen

/*
 * a)
 * addition component-by-component
 */
Point operator+(Point p1, Point p2) {
    Point res(p1.x() + p2.x(), p1.y() + p2.y());
    return res;
}

//substraction component-by-component
Point operator-(Point p1, Point p2) {
    Point res(p1.x() - p2.x(), p1.y() - p2.y());
    return res;
}

/*
 * b)
 * multiplication component-by-component
 */
Point operator*(Point p1, Point p2) {
    Point res(p1.x() * p2.x(), p1.y() * p2.y());
    return res;
}

//division component-by-component
Point operator/(Point p1, Point p2) {
    Point res(p1.x() / p2.x(), p1.y() / p2.y());
    return res;
}

/*
 * c)
 * scaling of the Point object with multiplication
 */
Point operator*(Point p, double s) {
    Point res(p.x() * s, p.y() * s);
    return res;
}

Point operator*(double s, Point p) {
    Point res(s * p.x(), s * p.y());
    return res;
}

/*
 * d)
 * scaling of the Point object with division
 */
Point operator/(Point p, double s) {
    Point res(p.x() / s, p.y() / s);
    return res;
}

/*
 * e)
 * Negation of the Point object
 */
Point operator-(Point p) {
    Point res(- p.x(), - p.y());
    return res;
}



void test_Point()
{
    typedef Point P; // neuer kurzer Name für 'Point'

    P p;
    assert(p.x() == 0);
    assert(p.y() == 0);

    // fuegen Sie Tests der arithmetischen Operationen hinzu

    //tests for arithmetic operations
    //define couple of Point objects
    Point a(2.0, 3.0), b(4.0, 5.0), c(2.7, 7.1);

    //tests a)
    Point r = a + b;
    assert(r == Point(6.0, 8.0));
    r = a + c;
    assert(r == Point(2.0 + 2.7, 3.0 + 7.1));
    r= b + c;
    assert(r == Point(4.0 + 2.7, 5.0 + 7.1));

    r = a - b;
    assert(r == Point(-2.0, -2.0));
    r = a - c;
    assert(r == Point(2.0 - 2.7, 3.0 - 7.1));
    r= b - c;
    assert(r == Point(4.0 - 2.7, 5.0 - 7.1));

    //tests b)
    r = a * b;
    assert(r == Point(8.0, 15.0));
    r = a * c;
    assert(r == Point(2.0 * 2.7, 3.0 * 7.1));
    r= b * c;
    assert(r == Point(4.0 * 2.7, 5.0 * 7.1));

    r = a / b;
    assert(r == Point(2.0 / 4.0, 3.0 / 5.0));
    r = a / c;
    assert(r == Point(2.0 / 2.7, 3.0 / 7.1));
    r= b / c;
    assert(r == Point(4.0 / 2.7, 5.0 / 7.1));

    //tests c)
    double s = 3.0;
    r = s * a;
    assert(r == Point(6.0, 9.0));
    r = s * b;
    assert(r == Point(3.0 * 4.0, 3.0 * 5.0));
    r = s * c;
    assert(r == Point(3.0 * 2.7, 3.0 * 7.1));

    r = a * s;
    assert(r == Point(6.0, 9.0));
    r = b * s;
    assert(r == Point(4.0 * 3.0, 5.0 * 3.0));
    r = c * s;
    assert(r == Point(2.7 * 3.0, 7.1 * 3.0));

    //tests d)
    r = a / s;
    assert(r == Point(2.0 / 3.0, 3.0 / 3.0));
    r = b / s;
    assert(r == Point(4.0 / 3.0, 5.0 / 3.0));
    r = c / s;
    assert(r == Point(2.7 / 3.0, 7.1 / 3.0));

    //tests e)
    r = -a;
    assert(r == Point(-2.0, -3.0));
    r = -b;
    assert(r == Point(-4.0, -5.0));
    r = -c;
    assert(r == Point(-2.7, -7.1));

    std::cout << "Alle Tests erfolgreich.\n";
}

int main()
{
    test_Point();
}
