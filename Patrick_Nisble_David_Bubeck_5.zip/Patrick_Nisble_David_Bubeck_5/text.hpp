#ifndef TEXT_HPP
#define TEXT_HPP

#include <string>

std::string str1 = "Nach einer Studie einer englischen Universitaet ist es egal, in welcher Reihenfolge die Buchstaben in einem Wort stehen. Das einzig Wichtige dabei ist, dass der erste und letzte Buchstabe am richtigen Platz sind. Der Rest kann totaler Bloedsinn sein, und man kann es trotzdem ohne Probleme lesen. Das geht deshalb, weil wir nicht Buchstabe fuer Buchstabe lesen, sondern Woerter als Ganzes.";
std::string str2 = "Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid.";
std::string str3 = "Am Anfang wurde das Universum erschaffen. Das machte viele Leute sehr wuetend und wurde allenthalben als Schritt in die falsche Richtung angesehen.";
std::string str4 = "Habe nun, ach! Philosophie, Juristerei und Medizin, Und leider auch Theologie Durchaus studiert, mit heissem Bemuehn. Da steh ich nun, ich armer Tor! Und bin so klug als wie zuvor.";
std::string str5 = "Im Atomstreit mit Iran zeichnen sich weitere UN-Sanktionen gegen das Land ab. Da eine klare Antwort aus Teheran auf ein Anreizpaket ausgeblieben sei, gebe es zu neuen Strafmassnahmen keine Alternative, teilte das US-Aussenministerium mit. Wie ein Ministeriumssprecher erklaerte, wollen die politischen Direktoren aus den Aussenministerien der fuenf UN-Vetomaechte und Deutschlands am Mittwoch in einer Telefonkonferenz ueber moegliche Reaktionen beraten."

#endif
