#ifndef FORMAT_NUMBERS_HPP
#define FORMAT_NUMBERS_HPP

#include <vector>

std::vector<double> numbers = {
    1234567.678,
   -3.0,
   -98765.4321,
   -300.4567,
    19.5,
    2.218,
   -7.324,
    7246.0,
    199.999,
    0.00001,
   -0.0002
};

#endif
